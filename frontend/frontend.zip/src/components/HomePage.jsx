import React from 'react'
import Sidebar from './Sidebar'
import MessageConatiner from './MessageConatiner'

const HomePage = () => {
  return (
    <div className='flex sm:h-[450px] md:h-[550px] rounded-lg overflow-hidden bg-gray-400 bg-clip-padding backdrop-filter backdrop-blur-lg bg-opacity-0'>
      <Sidebar/>
      <MessageConatiner />
    </div>
  )
}

export default HomePage